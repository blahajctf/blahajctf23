from flask import Flask, render_template, request
from selenium import webdriver
import os
from selenium.webdriver.chrome.options import Options

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/visit")
def visit():
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    with webdriver.Chrome() as driver:
        driver.get("http://127.0.0.1:50100")
        driver.add_cookie({"name": "favorite_site", "value": os.environ["flag"]})
        try:
            driver.get(request.args.get("site"))
            return "Visited"
        except:
            return "Invalid URL"
